﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

using WcfService1.ServiceDist;

namespace WcfService1.Resources
{
    public class BookDB
    {
        public List<bookclass> BookList;

        private Int64 IDcur = 0;

        private DataExport dataExport;

        private BookDB()
        {
            Sq = new ConcurrentQueue<List<bookclass>>();
            Lq = new ConcurrentQueue<string>();
            S = new Thread(() => dataExport.savedata(Sq, Lq)); //new Task<int>(() => dataExport.savedata(Sq, Lq));

            dataExport = new DataExport();

            S.Start();


            BookList = new List<bookclass>();
            List<bookclass> TempBookList = dataExport.readcsv();
            if (TempBookList.Count > 0)
            {
                foreach (bookclass book in TempBookList)
                {
                    BookList.Add(book);
                    if (book.ID > IDcur)
                        IDcur = book.ID;
                    //loginfo(1, book.ID);
                }
            }
        }

        private static BookDB instance;
        public static BookDB Instance
        {
            get { if(instance == null) { instance = new BookDB(); }

                instance.IDcur = 0;
                instance.BookList = new List<bookclass>();
                List<bookclass> TempBookList = instance.dataExport.readcsv();
                if (TempBookList.Count > 0)
                {
                    foreach (bookclass book in TempBookList)
                    {
                        instance.BookList.Add(book);
                        if (book.ID > instance.IDcur)
                            instance.IDcur = book.ID;
                        //loginfo(1, book.ID);
                    }
                }

                return instance; }
        }

        public Int64 getId()
        {
            IDcur += 1;
            return IDcur;
        }

        public Int64 AddBook(bookclass value, int servicenum)
        {
            int numbooks = BookList.Count - 1;
            if (numbooks == -1 || (BookList[numbooks].Bname != "" || BookList[numbooks].Gbook != "" && BookList[numbooks].Pbook != ""))
            {
                BookList.Add(value);
                loginfo(1, value.ID, servicenum);
                SaveDatabase();
                dataExport.writetofile(BookList);
                return value.ID;
            }
            else if (numbooks != -1)
            {
                return BookList[numbooks].ID;
            }
            return -1;
        }


        private ConcurrentQueue<List<bookclass>> Sq;
        private ConcurrentQueue<string> Lq;
        Thread S;

        public void SaveDatabase()
        {

            //var t = new Task<int>(() => dataExport.writetofile(BookList));
            //Sq.Enqueue(t);

            Sq.Enqueue(BookList);

            //dataExport.writetofile(BookList);
        }

        public void loginfo(int cmd, Int64 bookID, int servicenum)
        {
            string cmdstr = "";
            if (cmd == 1)
                cmdstr += " - service " + servicenum.ToString() + " --> Added Book: ";
            else if (cmd == 2)
                cmdstr += " - service " + servicenum.ToString() + " --> Deleted Book: ";
            else if (cmd == 3)
                cmdstr += " - service " + servicenum.ToString() + " --> Updated Book: ";

            Lq.Enqueue(DateTime.Now.ToString() + cmdstr + bookID.ToString());

            //if (k.Status != TaskStatus.Running && k.Status != TaskStatus.WaitingToRun)
            //{
                //k.Start(); //Run(() => dataExport.savedata(cq));
            //}

            //dataExport.logfile(cmd, bookID);
        }

        public bool SendInfoToDist(string portinfo)
        {
            try
            {
                ServiceDistClient client = new ServiceDistClient();
                client.AddServicePort(portinfo);
                client.Close();
            }
            catch
            {
                return false;
            }

            return true;
        }

    }

    public class bookclass
    {
        public Int64 ID { get; set; }

        public string Bname { get; set; }

        public string Gbook { get; set; }

        public string Pbook { get; set; }

        public string Stockbook { get; set; }

        public bool Removecheck { get; set; }

        public bookclass(Int64 tID, string name, string genre, string price, string stock, bool remcheck = false)
        {
            ID = tID;
            Bname = name;
            Gbook = genre;
            Pbook = price;
            Stockbook = stock;
            Removecheck = remcheck;
        }
    }
}