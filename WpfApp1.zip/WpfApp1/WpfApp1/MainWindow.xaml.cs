﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using WpfApp1.Resources;
using WpfApp1.Models;
using WpfApp1.ViewModel;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MainWindowModel DataInfo;
        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();

        //Service1Client client;

        public MainWindow()
        {

            InitializeComponent();

            DataInfo = new MainWindowModel();
            DataContext = DataInfo;
            DataInfo.stuff = dataGrid;

            DataInfo.initList();

            //timer if database didnt initiate
            if (DataInfo.bookCount() < 1)
            {
                dispatcherTimer.Tick += dispatcherTimer_Tick;
                dispatcherTimer.Interval = new TimeSpan(0, 0, 10);
                dispatcherTimer.Start();
            }
            

            //client = new Service1Client();


            //List<Book> filtlist = client.GetData(1);
            //dataGrid.ItemsSource = 
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            if(DataInfo.bookCount() < 1)
            {
                DataInfo.getbooks();
            }


        }

        private void WindowClosing(object sender, CancelEventArgs e)
        {
        }



        //add a empty row button
        private void button_AddBook_Click(object sender, RoutedEventArgs e)
        {
            DataInfo.Addbook();
            //MessageBox.Show(temp.Bname);
        }

        private void dataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            test bookval = dataGrid.SelectedItem as test;
            //MessageBox.Show(bookval.Bname);
            DataInfo.Editbook(bookval);
        }

        private void deletebuttons_Click(object sender, RoutedEventArgs e)
        {
            test bookval = dataGrid.SelectedItem as test;
            if (bookval != null)
            {
                DataInfo.DeleteBook(bookval.ID);
                MessageBox.Show(bookval.ID.ToString());
            }
        }




        //selection to change ordering of books based on numbers
        private void stock_dropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (stock_dropdown.SelectedIndex == 0)
            {
                if (DataInfo != null)
                    DataInfo.filtdata();
            }
            else if (stock_dropdown.SelectedIndex == 1)
            {
                price_dropdown.SelectedIndex = 0;
                DataInfo.filtdata(4);
            }
            else if (stock_dropdown.SelectedIndex == 2)
            {
                price_dropdown.SelectedIndex = 0;
                DataInfo.filtdata(5);
            }
            if (DataInfo != null)
                DataInfo.searchdatahelper();
        }
        private void price_dropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (price_dropdown.SelectedIndex == 0)
            {
                if (DataInfo != null)
                    DataInfo.filtdata();
            }
            else if (price_dropdown.SelectedIndex == 1)
            {
                stock_dropdown.SelectedIndex = 0;
                DataInfo.filtdata(6);
            }
            else if (price_dropdown.SelectedIndex == 2)
            {
                stock_dropdown.SelectedIndex = 0;
                DataInfo.filtdata(7);
            }

            if (DataInfo != null)
                DataInfo.searchdatahelper();
        }


        //search for book names or generes
        private void book_search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (book_search.Text != "")
                DataInfo.searchdata(2, book_search.Text);
            else
                DataInfo.searchdata();
        }

        private void genre_search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (genre_search.Text != "")
                DataInfo.searchdata(3, genre_search.Text);
            else
                DataInfo.searchdata();
        }

        //search buttons
        private void button_clearfilt_Click(object sender, RoutedEventArgs e)
        {
            genre_search.Text = "";
            book_search.Text = "";

            price_dropdown.SelectedIndex = 0;
            stock_dropdown.SelectedIndex = 0;

            DataInfo.searchdata();
        }
    }
}
