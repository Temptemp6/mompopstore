﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

using WpfApp1.Resources;
using System.ServiceModel;
using System.Text.Json;

namespace WpfApp1.ViewModel
{
    public class MainWindowModel
    {
        bool locking = false;
        public DataGrid stuff;

        private List<test> Books = new List<test>();

        //sorting values
        private int storedsearchval = 0;
        private int storedsortval = 0;
        private string storedsearchstr = "";
        public List<test> filtlist;

        private bool query = false;

        public MainWindowModel()
        {
            try
            {
                IServiceClient client = new IServiceClient();

                client.wcfClient1.InitData();
                string tempbooks = client.wcfClient1.GetData();
                Books = JsonSerializer.Deserialize<List<test>>(tempbooks);

                client.Close();

                //client.CloseClient();
            }
            catch { }
        }

        public int bookCount()
        {
            return Books.Count();
        }

        public void getbooks()
        {
            try
            {
                IServiceClient client = new IServiceClient();

                string tempbooks = client.wcfClient1.GetData();
                Books = JsonSerializer.Deserialize<List<test>>(tempbooks);
                searchdata(storedsearchval, storedsearchstr);

                client.Close();

                //client.CloseClient();
            }
            catch { }
        }

        public void initList()
        {
            searchdata(storedsearchval, storedsearchstr);
        }

        /*public List<test> Books
        {
            get
            {
                return client.GetData().ToList();
            }
        }*/

        public async void DeleteBook(Int64 ID)
        {
            if (locking == true)
                return;

            Books.RemoveAll(r => r.ID == ID);
            searchdata(storedsearchval, storedsearchstr);

            bool result = await Task.FromResult(deleteBook(ID)).Result;
            if(result == false)
            {
                try
                {
                    IServiceClient client = new IServiceClient();
                    string tempbooks = client.wcfClient1.GetData();
                    Books = JsonSerializer.Deserialize<List<test>>(tempbooks);
                    client.Close();
                }
                catch { }
                searchdata(storedsearchval, storedsearchstr);
            }
            //Debug.WriteLine(ID);

        }
        private async Task<bool> deleteBook(Int64 ID)
        {
            try
            {
                IServiceClient client = new IServiceClient();
                bool temp = client.wcfClient1.DeleteBook(ID);
                client.Close();
                return temp;
            }
            catch { }
            return false;
        }

        public async void Addbook()
        {
            if (Books[Books.Count - 1].Bname != "" || Books[Books.Count - 1].Gbook != "" && Books[Books.Count - 1].Pbook != "")
            {
                test temp = new test();
                temp.ID = -1; temp.Bname = ""; temp.Pbook = "0"; temp.Gbook = ""; temp.Stockbook = "0";
                Books.Add(temp);

                searchdata(storedsearchval, storedsearchstr);

                try
                {
                    Int64 newid = await Task.FromResult(addbook()).Result;
                    if(newid == -1)
                    {
                        Books.RemoveAll(r => r.ID == -1);
                        searchdata(storedsearchval, storedsearchstr);
                        return;
                    }

                    if (Books.Any(r => r.ID == newid) == true)
                    {
                        Books.RemoveAll(r => r.ID == -1);
                        searchdata(storedsearchval, storedsearchstr);
                        return;
                    }

                    Books.Where(r => r.ID == temp.ID).Select(r =>
                    {
                        r.ID = newid;
                        searchdata(storedsearchval, storedsearchstr);
                        return r;
                    }).ToList();
                    searchdata(storedsearchval, storedsearchstr);

                }
                catch
                {
                    Books.RemoveAll(r => r.ID == -1);
                    searchdata(storedsearchval, storedsearchstr);
                }

            }
        }
        private async Task<Int64> addbook()
        {
            Int64 newid = -1;
            try
            {
                IServiceClient client = new IServiceClient();
                Int64 temp = client.wcfClient1.AddBook(-1, "", "", "", "", true);
                client.Close();
                newid = temp;
            }
            catch
            {
                return newid;
            }
            return newid;
        }

        public async void Editbook(test editbook)
        {
            Books.Where(r => r.ID == editbook.ID).Select(r =>
            {
                r.Bname = editbook.Bname;
                r.Gbook = editbook.Gbook;
                r.Pbook = editbook.Pbook;
                r.Stockbook = editbook.Stockbook;
                return r;
            }).ToList();
            searchdata(storedsearchval, storedsearchstr);


            bool result = await Task.FromResult(editBook(editbook)).Result;
            if (result == false)
            {
                try
                {
                    IServiceClient client = new IServiceClient();
                    string tempbooks = client.wcfClient1.GetData();
                    Books = JsonSerializer.Deserialize<List<test>>(tempbooks);
                    client.Close();
                }
                catch { }
                searchdata(storedsearchval, storedsearchstr);
            }

        }

        private async Task<bool> editBook(test editbook)
        {
            try
            {
                IServiceClient client = new IServiceClient();
                bool temp = client.wcfClient1.EditBook((int)editbook.ID, editbook.Bname,editbook.Gbook,editbook.Pbook,editbook.Stockbook,editbook.Removecheck);
                client.Close();
                return temp;
            }
            catch { }
            return false;
        }


        //##########################################################################
        public void searchdatahelper()
        {
            searchdata(storedsearchval, storedsearchstr);
        }

        //search data
        public void searchdata(int sortval = 0, string searchstr = "")
        {
            storedsearchval = sortval;
            storedsearchstr = searchstr;

            if (sortval == 0) //show all
            {
                storedsearchstr = "";
                query = false;
                stuff.ItemsSource = Books.ToList();
                filtlist = Books.Cast<test>().ToList();
            }

            if (sortval == 2) //search book
            {
                query = true;

                var listvar1 = Books
                .Where(item => item.Bname.ToLower().Contains(searchstr.ToLower()))
                .Select(item => item);

                stuff.ItemsSource = listvar1.Cast<test>().ToList();
                filtlist = listvar1.Cast<test>().ToList();
            }
            if (sortval == 3)//search genre
            {
                query = true;

                var listvar2 = Books
                .Where(item => item.Gbook.ToLower().Contains(searchstr.ToLower()))
                .Select(item => item);

                stuff.ItemsSource = listvar2.Cast<test>().ToList();
                filtlist = listvar2.Cast<test>().ToList();
            }

            if (storedsortval != 0)
            {
                filtdata(storedsortval);
            }
        }

        //filter data
        public void filtdata(int sortval = 0)
        {
            if(filtlist == null)
            {
                filtlist = Books;
            }
            storedsortval = sortval;

            if (sortval == 0) //show all
            {
                query = false;
                //stuff.ItemsSource = Books;
                filtlist = Books.Cast<test>().ToList();
                stuff.ItemsSource = filtlist;
                return;
            }

            //ascen descend
            if (sortval == 4)
            {
                query = true;

                var listvar2 = filtlist
                .Where(item => item.Stockbook != "")
                .OrderBy(item => float.Parse(item.Stockbook))
                .Select(item => item);

                stuff.ItemsSource = listvar2.Cast<test>().ToList();
                filtlist = listvar2.Cast<test>().ToList();
                return;
            }
            if (sortval == 5)
            {
                query = true;

                var listvar2 = filtlist
                .Where(item => item.Stockbook != "")
                .OrderByDescending(item => float.Parse(item.Stockbook))
                .Select(item => item);

                stuff.ItemsSource = listvar2.Cast<test>().ToList();
                filtlist = listvar2.Cast<test>().ToList();
                return;
            }

            if (sortval == 6)
            {
                query = true;

                var listvar2 = filtlist
                .Where(item => item.Pbook != "")
                .OrderBy(item => float.Parse(item.Pbook))
                .Select(item => item);

                stuff.ItemsSource = listvar2.Cast<test>().ToList();
                filtlist = listvar2.Cast<test>().ToList();
                return;
            }
            if (sortval == 7)
            {
                query = true;

                var listvar2 = filtlist
                .Where(item => item.Pbook != "")
                .OrderByDescending(item => float.Parse(item.Pbook))
                .Select(item => item);

                stuff.ItemsSource = listvar2.Cast<test>().ToList();
                filtlist = listvar2.Cast<test>().ToList();
                return;
            }
        }
    }
}
