﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.ServiceModel;

using ServiceStarter.Resources;

using ServiceStarter.ServiceDist;



using System.Text.Json;

//using ServiceStarter.ServiceReference1;

namespace ServiceStarter
{


    class Program
    {
        //Service1Client client = new Service1Client();
        //Service1Client client = new Service1Client();


        static void Main(string[] args)
        {
            ConnectionClass connect = new ConnectionClass();

            connect.StartClients("63484");
            Console.WriteLine("----------------");
            connect.StartClients("53956");


            Console.WriteLine("Ports Added");
            

            while (true)
            {
                Console.WriteLine("\n-- Checking Clients --");
                connect.CheckForClients();
                Thread.Sleep(10000);
            }


            //Console.WriteLine(connect.CheckForClients());
            Console.ReadLine();
        }


        public class ConnectionClass
        {
            //Service1Client client = new Service1Client();

            public bool StartClients(string portnum)
            {
                try
                {
                    Console.WriteLine("starting...");

                    BasicHttpBinding myBinding = new BasicHttpBinding();

                    EndpointAddress myEndpoint = new EndpointAddress("http://localhost:" + portnum + "/Service1.svc"); //63484 //53956

                    ChannelFactory<IService> myChannelFactory = new ChannelFactory<IService>(myBinding, myEndpoint);

                    // Create a channel.
                    IService wcfClient1 = myChannelFactory.CreateChannel();
                    bool s = wcfClient1.ConnectDist();

                    //string tempstr = wcfClient1.GetData();
                    //List<test> templist = JsonSerializer.Deserialize<List<test>>(tempstr);
                    //Console.WriteLine(templist.Count);

                    //Console.WriteLine(s.ToString());
                    ((IClientChannel)wcfClient1).Close();
                    //other service

                    Console.WriteLine("Success on port {0}: {1}", portnum, s);
                }
                catch
                {
                    return false;
                }
                return true;
            }

            public void CheckForClients()
            {
                try
                {
                    ServiceDistClient client = new ServiceDistClient();
                    Console.WriteLine("Number of ports: {0}", client.NumOpenPorts());
                    client.CheckPorts();
                    int portsopen = client.NumOpenPorts();
                    Console.WriteLine("Number of ports after check: {0}", portsopen.ToString());
                    Console.WriteLine("Requesting port: {0}", client.RequestPort());
                    Console.WriteLine("Requesting port: {0}", client.RequestPort());
                    client.Close();

                    if (portsopen < 2)
                    {
                        StartClients("63484");
                        Console.WriteLine("----------------");
                        StartClients("53956");
                    }
                }
                catch
                {
                    StartClients("63484");
                    Console.WriteLine("----------------");
                    StartClients("53956");
                }

            }
        }
    }

    
}
