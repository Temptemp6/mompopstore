﻿using System;
using ServiceReference1;
using System.Threading.Tasks;

namespace ServiceStarter
{
    class Program
    {
        Service1Client client = new Service1Client();


        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        private async void connectservice()
        {

            ConnectDistResponse res = await client.ConnectDistAsync();
        }
    }
}
