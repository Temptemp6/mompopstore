﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;


using WcfService1.Resources;
using System.Threading.Tasks;

using System.Text.Json;

namespace WcfService2
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public void InitData()
        {
            BookDB bookinst = BookDB.Instance;

            //bookinst.AddBook(new test(bookinst.getId(), "Test1", "Tests", "10.1", "1", true));
        }

        public string GetData()
        {
            return JsonSerializer.Serialize<List<bookclass>>(BookDB.Instance.BookList);
        }

        public Int64 AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1)
        {
            BookDB bookinst = BookDB.Instance;

            Int64 newid = bookinst.getId();

            Int64 tempbool = bookinst.AddBook(new bookclass(newid, "", "", "0", "0", false), 2);
            //Books.RemoveAll(r => r.ID == value.ID);
            if (tempbool != -1)
                return tempbool;
            return -1;
        }

        public bool DeleteBook(Int64 IDval)
        {
            BookDB bookinst = BookDB.Instance;

            try
            {
                int pcount = bookinst.BookList.Count();
                bookinst.BookList.RemoveAll(r => r.ID == IDval);
                bookinst.loginfo(2, IDval, 2);
                bookinst.SaveDatabase();

                if (pcount == bookinst.BookList.Count())
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool EditBook(int val1, string str1, string str2, string str3, string str4, bool bool1)
        {
            bookclass editbook = new bookclass(val1,str1,str2,str3,str4,bool1);
            BookDB bookinst = BookDB.Instance;

            try
            {
                if (bookinst.BookList.Any(r => r.ID == val1) == false)
                {
                    return false;
                }

                bookinst.BookList.Where(r => r.ID == editbook.ID).Select(r =>
                {
                    r.Bname = editbook.Bname;
                    r.Gbook = editbook.Gbook;
                    r.Pbook = editbook.Pbook;
                    r.Stockbook = editbook.Stockbook;
                    return r;
                }).ToList();
            }
            catch
            {
                return false;
            }
            bookinst.loginfo(3, editbook.ID, 2);
            bookinst.SaveDatabase();
            return true;
        }

        public bool ConnectDist()
        {
            return BookDB.Instance.SendInfoToDist("63484");
        }


        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
